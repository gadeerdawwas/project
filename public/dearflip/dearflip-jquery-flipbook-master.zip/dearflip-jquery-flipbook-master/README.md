# [DearFlip jQuery Flipbook Plugin](https://dearflip.com/responsive-html5-flipbook-jquery-plugin/)
Create awesome 3D FlipBook from PDF or images using jQuery powered DearFlip plugin.


#### License: Attribution-NonCommercial-NoDerivatives 4.0 International
  
[![License: CC BY-NC-ND 4.0](https://img.shields.io/badge/License-CC%20BY--NC--ND%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc-nd/4.0/)

This is a non-commercial Lite Version. You are free to use for only personal non-profit use, testing/trial not otherwise.


For commercial versions follow the links below:

[jQuery Flipbook](https://dearflip.com/responsive-html5-flipbook-jquery-plugin/) or 
[WordPress Flipbook](https://dearflip.com/realistic-3d-flipbook-wordpress-plugin/)

For Desktop versions follow the links below:

[PDF Viewer](https://chrome.google.com/webstore/detail/pdf-to-flipbook-viewer-df/bbbnbmpdkfkndckfmcndgabefnmdedfp) Extension or 
[Flipbook](https://chrome.google.com/webstore/detail/pdf-flipbook-viewer-3d/ohckmemlgcohcakakmnpjchckcajpmdi) Chrome App

For Wordpress Demo: Get DearFlip lite Wordpress : [3D Flipbook](https://wordpress.org/plugins/3d-flipbook-dflip-lite/) from Wordpress Repository
 
